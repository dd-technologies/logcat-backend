const express = require('express');
const router = express.Router();

const upload = require('../helper/upload.helper');
const uploadController = require('../controller/upload.controller');
const { isAuth } = require('../middleware/authMiddleware');
 
router.post('/upload-single', upload.single('file'), uploadController.uploadSingle);
router.post('/upload-multiple', upload.array('files', 5), uploadController.uploadMultiple);

router.get('/get-uploaded-files', isAuth, uploadController.getUploadedS3file);
router.delete('/delete-file-byid/:id', isAuth, uploadController.deleteFile);

// router.get('/get-s3bucket-file', uploadController.getS3bucketData);

 // for upload error handling
router.post('/upload-single-v2', uploadController.uploadSingleV2);

module.exports = router;
